print("Hello, terminal!")
